import React, { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence, Reorder } from 'framer-motion';
import { Grid3X3, ArrowLeft, RotateCcw, Check, Sparkles } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import TerminalWindow from '@/components/TerminalWindow';
import AdaptiveHint, { HintType } from '@/components/AdaptiveHint';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header';
import MatrixBackground from '@/components/MatrixBackground';

const ORIGINAL_MESSAGE = 'SECURE THE DATA NOW';
const SCRAMBLED_BLOCKS = ['NOW', 'THE', 'SECURE', 'DATA'];
const CORRECT_ORDER = ['SECURE', 'THE', 'DATA', 'NOW'];

interface HintState {
  message: string;
  type: HintType;
  visible: boolean;
}

const Level2Transposition: React.FC = () => {
  const navigate = useNavigate();
  const [blocks, setBlocks] = useState<string[]>(SCRAMBLED_BLOCKS);
  const [isSuccess, setIsSuccess] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [hint, setHint] = useState<HintState>({
    message: '',
    type: 'info',
    visible: false,
  });

  // Check if level 1 is completed
  useEffect(() => {
    const completed = JSON.parse(localStorage.getItem('completedLevels') || '[]');
    if (!completed.includes(1)) {
      navigate('/');
    }
  }, [navigate]);

  const showHint = useCallback((message: string, type: HintType) => {
    setHint({ message, type, visible: true });
    setTimeout(() => {
      setHint((prev) => ({ ...prev, visible: false }));
    }, 5000);
  }, []);

  const handleCheck = useCallback(() => {
    setAttempts((prev) => prev + 1);

    const isCorrect = blocks.every((block, index) => block === CORRECT_ORDER[index]);

    if (isCorrect) {
      setIsSuccess(true);
      showHint(
        'Perfect! You\'ve successfully rearranged the transposed blocks to reveal the original message!',
        'success'
      );
      // Save completion
      const completed = JSON.parse(localStorage.getItem('completedLevels') || '[]');
      if (!completed.includes(2)) {
        localStorage.setItem('completedLevels', JSON.stringify([...completed, 2]));
      }
    } else {
      // Adaptive hints
      const firstCorrect = blocks[0] === CORRECT_ORDER[0];
      const lastCorrect = blocks[3] === CORRECT_ORDER[3];
      const middleCorrect = blocks[1] === CORRECT_ORDER[1] && blocks[2] === CORRECT_ORDER[2];

      if (firstCorrect && !lastCorrect) {
        showHint(
          'Good start! "SECURE" is in the right position. Think about what word would logically come at the end of a command.',
          'info'
        );
      } else if (!firstCorrect && lastCorrect) {
        showHint(
          'The ending is correct! But what word typically starts an important security directive?',
          'info'
        );
      } else if (middleCorrect && !firstCorrect) {
        showHint(
          'The middle blocks are correct! Now focus on which block should start the message.',
          'info'
        );
      } else if (attempts >= 3) {
        showHint(
          'Hint: Read the blocks as a sentence. What makes grammatical sense? The message is a security command.',
          'error'
        );
      } else {
        showHint(
          'Not quite right. Think about how these words would form a logical sentence. Drag blocks to reorder them.',
          'warning'
        );
      }
    }
  }, [blocks, attempts, showHint]);

  const handleReset = () => {
    setBlocks([...SCRAMBLED_BLOCKS]);
    setAttempts(0);
    setIsSuccess(false);
  };

  return (
    <div className="min-h-screen bg-background cyber-grid relative overflow-hidden">
      <MatrixBackground />
      <Header />

      <main className="container mx-auto px-4 pt-24 pb-12 relative z-10">
        <Link to="/">
          <Button variant="ghost" size="sm" className="mb-6">
            <ArrowLeft className="w-4 h-4" />
            Back to Levels
          </Button>
        </Link>

        {/* Level Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/30 mb-4">
            <Grid3X3 className="w-4 h-4 text-secondary" />
            <span className="text-sm font-mono text-secondary">LEVEL 2: TRANSPOSITION</span>
          </div>
          <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
            The Scrambled Orders
          </h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            A critical command has been scrambled using transposition. Drag and reorder
            the blocks to reveal the original message.
          </p>
        </motion.div>

        {/* Main Content */}
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Instructions */}
          <TerminalWindow title="mission_briefing.txt">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                <span className="text-secondary">$</span> Transposition cipher detected...
              </p>
              <p className="text-sm text-muted-foreground">
                <span className="text-secondary">$</span> Message blocks have been shuffled. Reorder to decrypt.
              </p>
              <p className="text-sm text-muted-foreground">
                <span className="text-secondary">$</span> Drag blocks to rearrange. Click "Verify" when ready.
              </p>
            </div>
          </TerminalWindow>

          {/* Drag and Drop Area */}
          <TerminalWindow title="block_cipher.exe">
            <div className="py-8">
              <p className="text-xs text-muted-foreground mb-4 text-center">
                DRAG TO REORDER BLOCKS:
              </p>
              
              <Reorder.Group
                axis="x"
                values={blocks}
                onReorder={setBlocks}
                className="flex flex-wrap justify-center gap-4"
              >
                {blocks.map((block) => (
                  <Reorder.Item
                    key={block}
                    value={block}
                    className={`
                      px-6 py-4 rounded-lg border-2 cursor-grab active:cursor-grabbing
                      font-display text-xl font-bold tracking-wider
                      transition-all duration-200
                      ${isSuccess
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-secondary bg-secondary/10 text-secondary hover:border-primary hover:bg-primary/10'
                      }
                    `}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    whileDrag={{ 
                      scale: 1.1, 
                      boxShadow: '0 0 30px hsl(var(--primary) / 0.5)',
                      zIndex: 50 
                    }}
                  >
                    {block}
                  </Reorder.Item>
                ))}
              </Reorder.Group>

              {/* Current Order Display */}
              <div className="mt-8 text-center">
                <p className="text-xs text-muted-foreground mb-2">CURRENT MESSAGE:</p>
                <motion.p
                  key={blocks.join('-')}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className={`text-xl font-display font-bold tracking-wider ${
                    isSuccess ? 'text-primary neon-text' : 'text-foreground'
                  }`}
                >
                  {blocks.join(' ')}
                </motion.p>
              </div>

              {/* Actions */}
              <div className="flex justify-center gap-4 mt-6">
                <Button variant="ghost" onClick={handleReset} disabled={isSuccess}>
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
                <Button variant="cyber" onClick={handleCheck} disabled={isSuccess}>
                  <Check className="w-4 h-4 mr-2" />
                  Verify Order
                </Button>
              </div>

              <p className="text-xs text-muted-foreground text-center mt-4">
                Attempts: {attempts}
              </p>
            </div>
          </TerminalWindow>

          {/* Hint Display */}
          <AdaptiveHint
            message={hint.message}
            type={hint.type}
            visible={hint.visible}
          />

          {/* Success State */}
          <AnimatePresence>
            {isSuccess && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="p-6 rounded-xl bg-primary/10 border border-primary text-center success-glow"
              >
                <motion.div
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                  className="inline-block mb-4"
                >
                  <Sparkles className="w-12 h-12 text-primary" />
                </motion.div>
                <h3 className="font-display text-xl font-bold text-primary mb-2">
                  MESSAGE DECODED
                </h3>
                <p className="text-muted-foreground mb-4">
                  The command is clear: "{ORIGINAL_MESSAGE}". Level 2 complete!
                </p>
                <Button
                  onClick={() => navigate('/level/3')}
                  variant="neon"
                  size="lg"
                >
                  Proceed to Level 3
                </Button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Educational Info */}
          <TerminalWindow title="crypto_info.md">
            <div className="prose prose-invert prose-sm max-w-none">
              <h4 className="text-secondary font-display text-lg mb-2">About Transposition Ciphers</h4>
              <p className="text-muted-foreground text-sm leading-relaxed">
                Unlike substitution ciphers, transposition ciphers don't replace letters — they <strong className="text-secondary">rearrange them</strong>.
                The letters (or blocks) of the message are shuffled according to a specific system.
              </p>
              <p className="text-muted-foreground text-sm leading-relaxed mt-2">
                <span className="text-secondary">Real-world example:</span> Rail fence ciphers write messages in a zigzag pattern,
                then read them row by row to create the encrypted text.
              </p>
            </div>
          </TerminalWindow>
        </div>
      </main>
    </div>
  );
};

export default Level2Transposition;
