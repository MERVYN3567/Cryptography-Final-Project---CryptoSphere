import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Lock, Grid3X3, Fingerprint, Shield, Zap, Target } from 'lucide-react';
import Header from '@/components/Header';
import LevelCard from '@/components/LevelCard';
import ProgressBar from '@/components/ProgressBar';
import TerminalWindow from '@/components/TerminalWindow';
import MatrixBackground from '@/components/MatrixBackground';
import { Button } from '@/components/ui/button';

const levels = [
  {
    level: 1,
    title: 'Caesar Cipher',
    description: 'Decode the encrypted message using the classic substitution cipher to unlock the server room.',
    icon: <Lock className="w-8 h-8 text-primary" />,
    route: '/level/1',
  },
  {
    level: 2,
    title: 'Transposition',
    description: 'Rearrange scrambled text blocks to reveal the hidden command using drag-and-drop.',
    icon: <Grid3X3 className="w-8 h-8 text-secondary" />,
    route: '/level/2',
  },
  {
    level: 3,
    title: 'Hash Functions',
    description: 'Explore SHA-256 hashing by modifying files and observing how fingerprints change.',
    icon: <Fingerprint className="w-8 h-8 text-accent" />,
    route: '/level/3',
  },
];

const Index: React.FC = () => {
  const navigate = useNavigate();
  const [completedLevels, setCompletedLevels] = useState<number[]>([]);
  const [typedText, setTypedText] = useState('');
  const fullText = '> Initializing CryptoSphere Interactive...';

  useEffect(() => {
    // Load completed levels from localStorage
    const saved = localStorage.getItem('completedLevels');
    if (saved) {
      setCompletedLevels(JSON.parse(saved));
    }
  }, []);

  useEffect(() => {
    // Typing animation
    if (typedText.length < fullText.length) {
      const timeout = setTimeout(() => {
        setTypedText(fullText.slice(0, typedText.length + 1));
      }, 50);
      return () => clearTimeout(timeout);
    }
  }, [typedText, fullText]);

  const isLevelLocked = (level: number): boolean => {
    if (level === 1) return false;
    return !completedLevels.includes(level - 1);
  };

  const handleLevelClick = (level: number, route: string) => {
    if (!isLevelLocked(level)) {
      navigate(route);
    }
  };

  const handleResetProgress = () => {
    localStorage.removeItem('completedLevels');
    setCompletedLevels([]);
  };

  return (
    <div className="min-h-screen bg-background cyber-grid relative overflow-hidden">
      <MatrixBackground />
      <Header />

      <main className="container mx-auto px-4 pt-24 pb-12 relative z-10">
        {/* Hero Section */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          {/* Logo */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
            className="inline-block mb-6"
          >
            <div className="w-24 h-24 rounded-2xl bg-primary/10 border-2 border-primary flex items-center justify-center mx-auto glow-border float-animation">
              <Shield className="w-12 h-12 text-primary" />
            </div>
          </motion.div>

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="font-display text-4xl md:text-6xl font-bold text-foreground mb-4"
          >
            <span className="neon-text">Crypto</span>
            <span className="neon-text-cyan">Sphere</span>
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-xl text-muted-foreground mb-6 max-w-2xl mx-auto"
          >
            Master the art of cryptography through interactive challenges.
            Learn substitution, transposition, and hashing in a gamified environment.
          </motion.p>

          {/* Terminal Animation */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="max-w-md mx-auto mb-8"
          >
            <div className="bg-card border border-border rounded-lg p-3 text-left">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-destructive" />
                <div className="w-2 h-2 rounded-full bg-yellow-500" />
                <div className="w-2 h-2 rounded-full bg-primary" />
              </div>
              <p className="font-mono text-sm text-primary">
                {typedText}
                <motion.span
                  animate={{ opacity: [1, 0] }}
                  transition={{ duration: 0.5, repeat: Infinity }}
                  className="inline-block w-2 h-4 bg-primary ml-1"
                />
              </p>
            </div>
          </motion.div>

          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex justify-center gap-8 mb-8"
          >
            <div className="text-center">
              <Zap className="w-6 h-6 text-primary mx-auto mb-1" />
              <p className="text-2xl font-display font-bold text-foreground">3</p>
              <p className="text-xs text-muted-foreground">Levels</p>
            </div>
            <div className="text-center">
              <Target className="w-6 h-6 text-secondary mx-auto mb-1" />
              <p className="text-2xl font-display font-bold text-foreground">{completedLevels.length}</p>
              <p className="text-xs text-muted-foreground">Completed</p>
            </div>
          </motion.div>
        </motion.section>

        {/* Progress Bar */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="mb-12"
        >
          <ProgressBar
            currentLevel={Math.min(completedLevels.length + 1, 3)}
            totalLevels={3}
            completedLevels={completedLevels}
          />
        </motion.section>

        {/* Level Cards */}
        <section className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-12">
          {levels.map((level) => (
            <LevelCard
              key={level.level}
              level={level.level}
              title={level.title}
              description={level.description}
              icon={level.icon}
              isLocked={isLevelLocked(level.level)}
              isCompleted={completedLevels.includes(level.level)}
              onClick={() => handleLevelClick(level.level, level.route)}
            />
          ))}
        </section>

        {/* Info Section */}
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="max-w-3xl mx-auto"
        >
          <TerminalWindow title="mission_briefing.txt">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <span className="text-primary">$</span>
                <div>
                  <p className="text-foreground font-bold mb-1">Welcome, Agent.</p>
                  <p className="text-muted-foreground text-sm">
                    You've been recruited to the CryptoSphere Academy. Your mission:
                    master three fundamental cryptographic techniques through hands-on challenges.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <span className="text-secondary">$</span>
                <div>
                  <p className="text-secondary font-bold mb-1">Adaptive Learning</p>
                  <p className="text-muted-foreground text-sm">
                    Don't worry about making mistakes. Our AI-powered hint system will guide you
                    with contextual feedback based on your specific errors.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <span className="text-accent">$</span>
                <div>
                  <p className="text-accent font-bold mb-1">Level Progression</p>
                  <p className="text-muted-foreground text-sm">
                    Complete each level to unlock the next. Your progress is saved automatically.
                  </p>
                </div>
              </div>

              {completedLevels.length > 0 && (
                <div className="pt-4 border-t border-border">
                  <Button variant="ghost" size="sm" onClick={handleResetProgress}>
                    Reset Progress
                  </Button>
                </div>
              )}
            </div>
          </TerminalWindow>
        </motion.section>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-border bg-background/80 backdrop-blur-sm py-6">
        <div className="container mx-auto px-4 text-center">
          <p className="text-xs text-muted-foreground">
            <span className="text-primary">CryptoSphere Interactive</span> — Educational Cybersecurity Platform
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Designed for secondary school students
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
