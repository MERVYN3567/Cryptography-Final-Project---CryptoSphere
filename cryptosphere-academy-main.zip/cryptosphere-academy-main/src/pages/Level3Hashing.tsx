import React, { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Fingerprint, ArrowLeft, FileText, Sparkles, RefreshCw } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import TerminalWindow from '@/components/TerminalWindow';
import AdaptiveHint, { HintType } from '@/components/AdaptiveHint';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import Header from '@/components/Header';
import MatrixBackground from '@/components/MatrixBackground';

interface HintState {
  message: string;
  type: HintType;
  visible: boolean;
}

// Simple SHA-256 simulation (for educational purposes)
async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

const Level3Hashing: React.FC = () => {
  const navigate = useNavigate();
  const [fileContent, setFileContent] = useState('The quick brown fox jumps over the lazy dog.');
  const [currentHash, setCurrentHash] = useState('');
  const [originalHash, setOriginalHash] = useState('');
  const [hasModified, setHasModified] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [experiments, setExperiments] = useState(0);
  const [hint, setHint] = useState<HintState>({
    message: '',
    type: 'info',
    visible: false,
  });

  // Check if previous levels are completed
  useEffect(() => {
    const completed = JSON.parse(localStorage.getItem('completedLevels') || '[]');
    if (!completed.includes(2)) {
      navigate('/');
    }
  }, [navigate]);

  // Calculate hash on mount and when content changes
  useEffect(() => {
    const calculateHash = async () => {
      const hash = await sha256(fileContent);
      setCurrentHash(hash);
      
      if (!originalHash) {
        setOriginalHash(hash);
      }
    };
    calculateHash();
  }, [fileContent, originalHash]);

  const showHint = useCallback((message: string, type: HintType) => {
    setHint({ message, type, visible: true });
    setTimeout(() => {
      setHint((prev) => ({ ...prev, visible: false }));
    }, 6000);
  }, []);

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newContent = e.target.value;
    setFileContent(newContent);
    
    if (!hasModified && newContent !== 'The quick brown fox jumps over the lazy dog.') {
      setHasModified(true);
      setExperiments((prev) => prev + 1);
    }
  };

  const handleVerify = useCallback(() => {
    if (!hasModified) {
      showHint(
        'You haven\'t modified the file yet! Try changing even a single character to see how the hash changes.',
        'warning'
      );
      return;
    }

    if (experiments < 2) {
      showHint(
        'Good observation! Try making a few more modifications to see the pattern. Even tiny changes create completely different hashes.',
        'info'
      );
      return;
    }

    // Check if they've experimented enough
    if (experiments >= 2 && currentHash !== originalHash) {
      setIsSuccess(true);
      showHint(
        'Excellent work! You\'ve discovered the avalanche effect — even tiny changes produce completely different hash values!',
        'success'
      );
      // Save completion
      const completed = JSON.parse(localStorage.getItem('completedLevels') || '[]');
      if (!completed.includes(3)) {
        localStorage.setItem('completedLevels', JSON.stringify([...completed, 3]));
      }
    }
  }, [hasModified, experiments, currentHash, originalHash, showHint]);

  const handleReset = async () => {
    const originalContent = 'The quick brown fox jumps over the lazy dog.';
    setFileContent(originalContent);
    setHasModified(false);
    const hash = await sha256(originalContent);
    setCurrentHash(hash);
    setOriginalHash(hash);
  };

  // Visualize hash differences
  const renderHashComparison = () => {
    const chars1 = originalHash.split('');
    const chars2 = currentHash.split('');
    
    return (
      <div className="font-mono text-xs break-all">
        <div className="mb-2">
          <span className="text-muted-foreground">Original: </span>
          <span className="text-primary/70">{originalHash.slice(0, 32)}...</span>
        </div>
        <div>
          <span className="text-muted-foreground">Current:  </span>
          {chars2.slice(0, 32).map((char, i) => (
            <span
              key={i}
              className={char !== chars1[i] ? 'text-destructive font-bold' : 'text-secondary'}
            >
              {char}
            </span>
          ))}
          <span className="text-secondary">...</span>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background cyber-grid relative overflow-hidden">
      <MatrixBackground />
      <Header />

      <main className="container mx-auto px-4 pt-24 pb-12 relative z-10">
        <Link to="/">
          <Button variant="ghost" size="sm" className="mb-6">
            <ArrowLeft className="w-4 h-4" />
            Back to Levels
          </Button>
        </Link>

        {/* Level Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/30 mb-4">
            <Fingerprint className="w-4 h-4 text-accent" />
            <span className="text-sm font-mono text-accent">LEVEL 3: HASHING</span>
          </div>
          <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
            The Digital Fingerprint
          </h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Explore how cryptographic hashing creates unique "fingerprints" for data.
            Modify the file and watch the SHA-256 hash change in real-time.
          </p>
        </motion.div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-6 max-w-6xl mx-auto">
          {/* Left: File Editor */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <TerminalWindow title="document.txt">
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <FileText className="w-4 h-4" />
                  <span>Edit the file content below:</span>
                </div>
                <Textarea
                  value={fileContent}
                  onChange={handleContentChange}
                  className="min-h-[200px] bg-background border-border text-foreground font-mono text-sm resize-none"
                  placeholder="Enter some text..."
                  disabled={isSuccess}
                />
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">
                    Characters: {fileContent.length}
                  </span>
                  <Button variant="ghost" size="sm" onClick={handleReset}>
                    <RefreshCw className="w-3 h-3 mr-1" />
                    Reset
                  </Button>
                </div>
              </div>
            </TerminalWindow>

            {/* Hash Comparison */}
            <TerminalWindow title="hash_comparison.log">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-xs">
                  <div className={`w-2 h-2 rounded-full ${hasModified ? 'bg-destructive' : 'bg-primary'}`} />
                  <span className={hasModified ? 'text-destructive' : 'text-primary'}>
                    {hasModified ? 'FILE MODIFIED' : 'FILE UNCHANGED'}
                  </span>
                </div>
                {renderHashComparison()}
                <p className="text-xs text-muted-foreground">
                  * Red characters indicate differences from original
                </p>
              </div>
            </TerminalWindow>
          </motion.div>

          {/* Right: Hash Display & Scanner */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-4"
          >
            {/* Hash Scanner Visualization */}
            <TerminalWindow title="sha256_scanner.exe">
              <div className="text-center py-6">
                <motion.div
                  animate={{ 
                    boxShadow: hasModified 
                      ? ['0 0 20px hsl(var(--destructive)/0.5)', '0 0 40px hsl(var(--destructive)/0.3)', '0 0 20px hsl(var(--destructive)/0.5)']
                      : ['0 0 20px hsl(var(--primary)/0.5)', '0 0 40px hsl(var(--primary)/0.3)', '0 0 20px hsl(var(--primary)/0.5)']
                  }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className={`
                    w-32 h-32 mx-auto rounded-full border-4 flex items-center justify-center mb-4
                    ${hasModified ? 'border-destructive bg-destructive/10' : 'border-primary bg-primary/10'}
                  `}
                >
                  <Fingerprint className={`w-16 h-16 ${hasModified ? 'text-destructive' : 'text-primary'}`} />
                </motion.div>
                
                <p className="text-xs text-muted-foreground mb-2">SHA-256 HASH:</p>
                <motion.div
                  key={currentHash}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="font-mono text-xs text-accent break-all px-4 leading-relaxed"
                >
                  {currentHash}
                </motion.div>
              </div>
            </TerminalWindow>

            {/* Experiment Counter */}
            <TerminalWindow title="experiment_log.txt">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Modifications made:</span>
                  <span className="text-lg font-display font-bold text-accent">{experiments}</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.min(experiments * 50, 100)}%` }}
                    className="h-full bg-gradient-to-r from-accent to-primary"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  {experiments < 2 
                    ? 'Make at least 2 modifications to complete the experiment'
                    : 'Ready to verify your understanding!'
                  }
                </p>
                <Button
                  variant="cyber"
                  onClick={handleVerify}
                  disabled={isSuccess}
                  className="w-full"
                >
                  Verify Understanding
                </Button>
              </div>
            </TerminalWindow>

            {/* Hint Display */}
            <AdaptiveHint
              message={hint.message}
              type={hint.type}
              visible={hint.visible}
            />
          </motion.div>
        </div>

        {/* Success State */}
        <AnimatePresence>
          {isSuccess && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="max-w-2xl mx-auto mt-8 p-6 rounded-xl bg-primary/10 border border-primary text-center success-glow"
            >
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                className="inline-block mb-4"
              >
                <Sparkles className="w-12 h-12 text-primary" />
              </motion.div>
              <h3 className="font-display text-xl font-bold text-primary mb-2">
                MISSION COMPLETE
              </h3>
              <p className="text-muted-foreground mb-4">
                You've mastered all three levels of CryptoSphere Interactive!
                You now understand substitution, transposition, and hashing.
              </p>
              <Button
                onClick={() => navigate('/')}
                variant="neon"
                size="lg"
              >
                Return to Home
              </Button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Educational Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8 max-w-3xl mx-auto"
        >
          <TerminalWindow title="crypto_info.md">
            <div className="prose prose-invert prose-sm max-w-none">
              <h4 className="text-accent font-display text-lg mb-2">About Cryptographic Hashing</h4>
              <p className="text-muted-foreground text-sm leading-relaxed">
                A hash function takes any input and produces a fixed-length output called a <strong className="text-accent">hash</strong> or
                "digital fingerprint." SHA-256 always produces a 256-bit (64 hexadecimal character) output.
              </p>
              <div className="mt-3 space-y-2 text-sm text-muted-foreground">
                <p>
                  <span className="text-accent">Key Properties:</span>
                </p>
                <ul className="list-disc list-inside space-y-1">
                  <li><strong className="text-foreground">Deterministic:</strong> Same input always gives the same hash</li>
                  <li><strong className="text-foreground">One-way:</strong> Cannot reverse a hash to find the original input</li>
                  <li><strong className="text-foreground">Avalanche effect:</strong> Tiny changes cause massive hash differences</li>
                  <li><strong className="text-foreground">Collision resistant:</strong> Very hard to find two inputs with the same hash</li>
                </ul>
              </div>
            </div>
          </TerminalWindow>
        </motion.div>
      </main>
    </div>
  );
};

export default Level3Hashing;
