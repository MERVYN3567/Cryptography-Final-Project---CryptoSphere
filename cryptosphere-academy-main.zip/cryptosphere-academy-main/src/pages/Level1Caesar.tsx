import React, { useState, useMemo, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, ArrowLeft, RotateCcw, Send, Sparkles } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import CaesarCipherWheel from '@/components/CaesarCipherWheel';
import AdaptiveHint, { HintType } from '@/components/AdaptiveHint';
import TerminalWindow from '@/components/TerminalWindow';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Header from '@/components/Header';
import MatrixBackground from '@/components/MatrixBackground';

// The secret message and its shift value
const SECRET_SHIFT = 7;
const ORIGINAL_MESSAGE = 'ACCESS GRANTED';
const ENCRYPTED_MESSAGE = 'HJJLZZ NYHUALK'; // Shifted by 7

interface HintState {
  message: string;
  type: HintType;
  visible: boolean;
}

const Level1Caesar: React.FC = () => {
  const navigate = useNavigate();
  const [currentShift, setCurrentShift] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [hint, setHint] = useState<HintState>({
    message: '',
    type: 'info',
    visible: false,
  });

  // Decode the encrypted message with current shift
  const decodedMessage = useMemo(() => {
    return ENCRYPTED_MESSAGE.split('')
      .map((char) => {
        if (char === ' ') return ' ';
        const code = char.charCodeAt(0) - 65;
        const shifted = (code - currentShift + 26) % 26;
        return String.fromCharCode(shifted + 65);
      })
      .join('');
  }, [currentShift]);

  const showHint = useCallback((message: string, type: HintType) => {
    setHint({ message, type, visible: true });
    setTimeout(() => {
      setHint((prev) => ({ ...prev, visible: false }));
    }, 5000);
  }, []);

  const handleSubmit = useCallback(() => {
    setAttempts((prev) => prev + 1);
    const normalizedAnswer = userAnswer.toUpperCase().trim();

    if (normalizedAnswer === ORIGINAL_MESSAGE) {
      setIsSuccess(true);
      showHint(
        'Excellent work, agent! You\'ve successfully decoded the Caesar cipher and unlocked the server room!',
        'success'
      );
      // Save completion to localStorage
      const completed = JSON.parse(localStorage.getItem('completedLevels') || '[]');
      if (!completed.includes(1)) {
        localStorage.setItem('completedLevels', JSON.stringify([...completed, 1]));
      }
    } else {
      // Adaptive hints based on user's attempt
      if (currentShift === 0) {
        showHint(
          'The wheel hasn\'t been rotated yet. The cipher uses a shift — try turning the inner wheel to see how letters change.',
          'warning'
        );
      } else if (currentShift !== SECRET_SHIFT && Math.abs(currentShift - SECRET_SHIFT) <= 2) {
        showHint(
          `You're very close! Your shift is ${currentShift > SECRET_SHIFT ? 'a little too high' : 'a little too low'}. Fine-tune the wheel.`,
          'info'
        );
      } else if (currentShift === SECRET_SHIFT && normalizedAnswer !== ORIGINAL_MESSAGE) {
        showHint(
          'Your shift value looks correct! Check your spelling — the decoded message should read clearly.',
          'info'
        );
      } else if (attempts >= 3) {
        showHint(
          'Hint: In a Caesar cipher, each letter is shifted by the same amount. The correct shift for this message is somewhere between 5 and 10.',
          'error'
        );
      } else {
        showHint(
          'Not quite right. Watch how the inner wheel letters align with the outer wheel. The decoded message should make sense in English.',
          'warning'
        );
      }
    }
  }, [userAnswer, currentShift, attempts, showHint]);

  const handleReset = () => {
    setCurrentShift(0);
    setUserAnswer('');
    setAttempts(0);
    setIsSuccess(false);
  };

  return (
    <div className="min-h-screen bg-background cyber-grid relative overflow-hidden">
      <MatrixBackground />
      <Header />

      <main className="container mx-auto px-4 pt-24 pb-12 relative z-10">
        {/* Back Button */}
        <Link to="/">
          <Button variant="ghost" size="sm" className="mb-6">
            <ArrowLeft className="w-4 h-4" />
            Back to Levels
          </Button>
        </Link>

        {/* Level Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 mb-4">
            <Lock className="w-4 h-4 text-primary" />
            <span className="text-sm font-mono text-primary">LEVEL 1: SUBSTITUTION</span>
          </div>
          <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-2">
            The Locked Server Room
          </h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            An encrypted message blocks your entry. Use the Caesar cipher wheel to decode
            the secret passphrase and unlock the door.
          </p>
        </motion.div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Left: Cipher Wheel */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <TerminalWindow title="cipher_wheel.exe">
              <div className="flex flex-col items-center py-4">
                <CaesarCipherWheel
                  currentShift={currentShift}
                  onShiftChange={setCurrentShift}
                />
              </div>
            </TerminalWindow>
          </motion.div>

          {/* Right: Challenge */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-6"
          >
            {/* Encrypted Message */}
            <TerminalWindow title="encrypted_message.txt">
              <div className="space-y-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-2">INTERCEPTED MESSAGE:</p>
                  <p className="text-2xl font-display font-bold text-destructive tracking-wider">
                    {ENCRYPTED_MESSAGE}
                  </p>
                </div>
                <div className="border-t border-border pt-4">
                  <p className="text-xs text-muted-foreground mb-2">DECODED (SHIFT: {currentShift}):</p>
                  <motion.p
                    key={decodedMessage}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={`text-2xl font-display font-bold tracking-wider ${
                      decodedMessage === ORIGINAL_MESSAGE
                        ? 'text-primary neon-text'
                        : 'text-secondary'
                    }`}
                  >
                    {decodedMessage}
                  </motion.p>
                </div>
              </div>
            </TerminalWindow>

            {/* Answer Input */}
            <TerminalWindow title="access_panel.exe">
              <div className="space-y-4">
                <div>
                  <label className="text-xs text-muted-foreground mb-2 block">
                    ENTER DECODED PASSPHRASE:
                  </label>
                  <div className="flex gap-2">
                    <Input
                      value={userAnswer}
                      onChange={(e) => setUserAnswer(e.target.value)}
                      placeholder="Type the decoded message..."
                      className="bg-background border-border text-foreground uppercase tracking-wider"
                      disabled={isSuccess}
                      onKeyDown={(e) => e.key === 'Enter' && !isSuccess && handleSubmit()}
                    />
                    <Button
                      onClick={handleSubmit}
                      disabled={isSuccess || !userAnswer.trim()}
                      variant="cyber"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Attempts Counter */}
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Attempts: {attempts}</span>
                  <Button variant="ghost" size="sm" onClick={handleReset}>
                    <RotateCcw className="w-3 h-3 mr-1" />
                    Reset
                  </Button>
                </div>
              </div>
            </TerminalWindow>

            {/* Hint Display */}
            <AdaptiveHint
              message={hint.message}
              type={hint.type}
              visible={hint.visible}
            />

            {/* Success State */}
            <AnimatePresence>
              {isSuccess && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="p-6 rounded-xl bg-primary/10 border border-primary text-center success-glow"
                >
                  <motion.div
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                    className="inline-block mb-4"
                  >
                    <Sparkles className="w-12 h-12 text-primary" />
                  </motion.div>
                  <h3 className="font-display text-xl font-bold text-primary mb-2">
                    ACCESS GRANTED
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    The server room door clicks open. Level 1 complete!
                  </p>
                  <Button
                    onClick={() => navigate('/level/2')}
                    variant="neon"
                    size="lg"
                  >
                    Proceed to Level 2
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Educational Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-12 max-w-3xl mx-auto"
        >
          <TerminalWindow title="crypto_info.md">
            <div className="prose prose-invert prose-sm max-w-none">
              <h4 className="text-primary font-display text-lg mb-2">About Caesar Cipher</h4>
              <p className="text-muted-foreground text-sm leading-relaxed">
                The Caesar cipher is one of the oldest encryption techniques, named after Julius Caesar
                who used it in his private correspondence. It's a type of <strong className="text-secondary">substitution cipher</strong> where
                each letter is replaced by another letter a fixed number of positions down the alphabet.
              </p>
              <p className="text-muted-foreground text-sm leading-relaxed mt-2">
                <span className="text-primary">Example:</span> With a shift of 3, 'A' becomes 'D', 'B' becomes 'E', and so on.
                To decrypt, simply shift in the opposite direction.
              </p>
            </div>
          </TerminalWindow>
        </motion.div>
      </main>
    </div>
  );
};

export default Level1Caesar;
