import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lightbulb, AlertTriangle, CheckCircle, Info } from 'lucide-react';

export type HintType = 'info' | 'warning' | 'success' | 'error';

interface AdaptiveHintProps {
  message: string;
  type: HintType;
  visible: boolean;
}

const hintConfig = {
  info: {
    icon: Info,
    bgClass: 'bg-secondary/10 border-secondary',
    textClass: 'text-secondary',
    glowClass: 'shadow-[0_0_20px_hsl(var(--secondary)/0.3)]',
  },
  warning: {
    icon: AlertTriangle,
    bgClass: 'bg-yellow-500/10 border-yellow-500',
    textClass: 'text-yellow-500',
    glowClass: 'shadow-[0_0_20px_hsl(45_100%_50%/0.3)]',
  },
  success: {
    icon: CheckCircle,
    bgClass: 'bg-primary/10 border-primary',
    textClass: 'text-primary',
    glowClass: 'shadow-[0_0_20px_hsl(var(--primary)/0.5)]',
  },
  error: {
    icon: Lightbulb,
    bgClass: 'bg-accent/10 border-accent',
    textClass: 'text-accent',
    glowClass: 'shadow-[0_0_20px_hsl(var(--accent)/0.3)]',
  },
};

const AdaptiveHint: React.FC<AdaptiveHintProps> = ({ message, type, visible }) => {
  const config = hintConfig[type];
  const Icon = config.icon;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -10, scale: 0.95 }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
          className={`
            rounded-lg border p-4 
            ${config.bgClass} 
            ${config.glowClass}
            backdrop-blur-sm
          `}
        >
          <div className="flex items-start gap-3">
            <motion.div
              initial={{ rotate: -20 }}
              animate={{ rotate: 0 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <Icon className={`w-5 h-5 ${config.textClass} flex-shrink-0 mt-0.5`} />
            </motion.div>
            <div>
              <p className={`text-sm font-medium ${config.textClass} mb-1`}>
                {type === 'info' && 'Hint'}
                {type === 'warning' && 'Check Your Approach'}
                {type === 'success' && 'Excellent!'}
                {type === 'error' && 'Try This'}
              </p>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {message}
              </p>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AdaptiveHint;
