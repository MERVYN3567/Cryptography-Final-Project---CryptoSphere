import React from 'react';
import { motion } from 'framer-motion';

interface ProgressBarProps {
  currentLevel: number;
  totalLevels: number;
  completedLevels: number[];
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  currentLevel,
  totalLevels,
  completedLevels,
}) => {
  const progress = (completedLevels.length / totalLevels) * 100;

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="flex justify-between items-center mb-2">
        <span className="text-xs text-muted-foreground font-mono">
          MISSION PROGRESS
        </span>
        <span className="text-xs text-primary font-mono">
          {completedLevels.length}/{totalLevels} COMPLETE
        </span>
      </div>
      
      <div className="relative h-3 bg-muted rounded-full overflow-hidden border border-border">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 1, ease: 'easeOut' }}
          className="absolute inset-y-0 left-0 bg-gradient-to-r from-primary to-secondary rounded-full"
        />
        
        {/* Level markers */}
        <div className="absolute inset-0 flex">
          {Array.from({ length: totalLevels }).map((_, index) => (
            <div
              key={index}
              className="flex-1 border-r border-background/50 last:border-r-0"
            />
          ))}
        </div>

        {/* Glow effect */}
        <motion.div
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/30 to-transparent"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Level indicators */}
      <div className="flex justify-between mt-2">
        {Array.from({ length: totalLevels }).map((_, index) => (
          <motion.div
            key={index}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className={`
              w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold
              ${completedLevels.includes(index + 1)
                ? 'bg-primary text-primary-foreground'
                : index + 1 === currentLevel
                  ? 'bg-secondary/20 border-2 border-secondary text-secondary'
                  : 'bg-muted text-muted-foreground'
              }
            `}
          >
            {index + 1}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ProgressBar;
