import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface CaesarCipherWheelProps {
  currentShift: number;
  onShiftChange: (shift: number) => void;
}

const CaesarCipherWheel: React.FC<CaesarCipherWheelProps> = ({
  currentShift,
  onShiftChange,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
  
  const getShiftedLetter = (index: number): string => {
    const shiftedIndex = (index + currentShift + 26) % 26;
    return alphabet[shiftedIndex];
  };

  const handleShiftLeft = useCallback(() => {
    onShiftChange((currentShift - 1 + 26) % 26);
  }, [currentShift, onShiftChange]);

  const handleShiftRight = useCallback(() => {
    onShiftChange((currentShift + 1) % 26);
  }, [currentShift, onShiftChange]);

  const outerRadius = 140;
  const innerRadius = 100;
  const centerX = 160;
  const centerY = 160;

  return (
    <div className="relative flex flex-col items-center">
      {/* Control Buttons */}
      <div className="flex items-center gap-4 mb-6">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleShiftLeft}
          className="w-12 h-12 rounded-full border-2 border-primary bg-background flex items-center justify-center text-primary hover:bg-primary/10 transition-all shadow-[0_0_15px_hsl(var(--primary)/0.4)]"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </motion.button>
        
        <div className="text-center">
          <p className="text-muted-foreground text-sm">Shift Value</p>
          <motion.p 
            key={currentShift}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-3xl font-display font-bold text-primary neon-text"
          >
            {currentShift}
          </motion.p>
        </div>
        
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleShiftRight}
          className="w-12 h-12 rounded-full border-2 border-primary bg-background flex items-center justify-center text-primary hover:bg-primary/10 transition-all shadow-[0_0_15px_hsl(var(--primary)/0.4)]"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M9 18l6-6-6-6" />
          </svg>
        </motion.button>
      </div>

      {/* Cipher Wheel SVG */}
      <div className="relative">
        <svg width="320" height="320" viewBox="0 0 320 320" className="drop-shadow-2xl">
          {/* Outer Ring Background */}
          <circle
            cx={centerX}
            cy={centerY}
            r={outerRadius + 15}
            fill="hsl(var(--card))"
            stroke="hsl(var(--border))"
            strokeWidth="2"
          />
          
          {/* Outer Ring (Fixed) */}
          <g>
            {alphabet.map((letter, index) => {
              const angle = (index * 360) / 26 - 90;
              const radians = (angle * Math.PI) / 180;
              const x = centerX + outerRadius * Math.cos(radians);
              const y = centerY + outerRadius * Math.sin(radians);
              
              return (
                <g key={`outer-${index}`}>
                  <circle
                    cx={x}
                    cy={y}
                    r="14"
                    fill="hsl(var(--muted))"
                    stroke="hsl(var(--primary))"
                    strokeWidth="1"
                  />
                  <text
                    x={x}
                    y={y}
                    textAnchor="middle"
                    dominantBaseline="central"
                    fill="hsl(var(--primary))"
                    fontSize="12"
                    fontFamily="Orbitron, sans-serif"
                    fontWeight="bold"
                  >
                    {letter}
                  </text>
                </g>
              );
            })}
          </g>

          {/* Inner Ring (Rotates) */}
          <motion.g
            animate={{ rotate: currentShift * (360 / 26) }}
            transition={{ type: "spring", stiffness: 100, damping: 15 }}
            style={{ transformOrigin: `${centerX}px ${centerY}px` }}
          >
            <circle
              cx={centerX}
              cy={centerY}
              r={innerRadius + 15}
              fill="hsl(var(--background))"
              stroke="hsl(var(--secondary))"
              strokeWidth="2"
            />
            {alphabet.map((letter, index) => {
              const angle = (index * 360) / 26 - 90;
              const radians = (angle * Math.PI) / 180;
              const x = centerX + innerRadius * Math.cos(radians);
              const y = centerY + innerRadius * Math.sin(radians);
              
              return (
                <g key={`inner-${index}`}>
                  <circle
                    cx={x}
                    cy={y}
                    r="12"
                    fill="hsl(var(--secondary)/0.2)"
                    stroke="hsl(var(--secondary))"
                    strokeWidth="1"
                  />
                  <text
                    x={x}
                    y={y}
                    textAnchor="middle"
                    dominantBaseline="central"
                    fill="hsl(var(--secondary))"
                    fontSize="11"
                    fontFamily="Orbitron, sans-serif"
                    fontWeight="bold"
                  >
                    {letter}
                  </text>
                </g>
              );
            })}
          </motion.g>

          {/* Center */}
          <circle
            cx={centerX}
            cy={centerY}
            r="35"
            fill="hsl(var(--card))"
            stroke="hsl(var(--primary))"
            strokeWidth="2"
            className="drop-shadow-lg"
          />
          <text
            x={centerX}
            y={centerY - 8}
            textAnchor="middle"
            fill="hsl(var(--primary))"
            fontSize="10"
            fontFamily="Orbitron, sans-serif"
          >
            CIPHER
          </text>
          <text
            x={centerX}
            y={centerY + 8}
            textAnchor="middle"
            fill="hsl(var(--secondary))"
            fontSize="10"
            fontFamily="Orbitron, sans-serif"
          >
            WHEEL
          </text>

          {/* Pointer */}
          <polygon
            points={`${centerX},${centerY - outerRadius - 25} ${centerX - 8},${centerY - outerRadius - 35} ${centerX + 8},${centerY - outerRadius - 35}`}
            fill="hsl(var(--primary))"
            className="drop-shadow-lg"
          />
        </svg>

        {/* Glow Effect */}
        <div className="absolute inset-0 rounded-full bg-primary/5 blur-xl pointer-events-none" />
      </div>

      {/* Mapping Display */}
      <div className="mt-6 grid grid-cols-13 gap-1 max-w-md">
        {alphabet.slice(0, 13).map((letter, index) => (
          <motion.div
            key={`map-${index}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.02 }}
            className="text-center"
          >
            <div className="text-xs text-muted-foreground">{letter}</div>
            <div className="text-xs text-primary">↓</div>
            <motion.div 
              key={`${letter}-${currentShift}`}
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="text-xs text-secondary font-bold"
            >
              {getShiftedLetter(index)}
            </motion.div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default CaesarCipherWheel;
