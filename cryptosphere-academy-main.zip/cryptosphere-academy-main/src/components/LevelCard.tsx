import React from 'react';
import { motion } from 'framer-motion';
import { Lock, Unlock, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';

interface LevelCardProps {
  level: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  isLocked: boolean;
  isCompleted: boolean;
  onClick: () => void;
}

const LevelCard: React.FC<LevelCardProps> = ({
  level,
  title,
  description,
  icon,
  isLocked,
  isCompleted,
  onClick,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: level * 0.1 }}
      whileHover={!isLocked ? { scale: 1.02, y: -5 } : {}}
      className={`
        level-card relative
        ${isLocked ? 'opacity-60' : ''}
        ${isCompleted ? 'border-primary success-glow' : ''}
      `}
    >
      {/* Level Number Badge */}
      <div className="absolute -top-3 -left-3 w-10 h-10 rounded-full bg-background border-2 border-primary flex items-center justify-center">
        <span className="font-display font-bold text-primary text-sm">
          {level}
        </span>
      </div>

      {/* Lock/Status Icon */}
      <div className="absolute -top-3 -right-3">
        {isLocked ? (
          <motion.div
            animate={{ rotate: [0, -5, 5, 0] }}
            transition={{ repeat: Infinity, duration: 2, repeatDelay: 3 }}
            className="w-10 h-10 rounded-full bg-muted border border-border flex items-center justify-center"
          >
            <Lock className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        ) : isCompleted ? (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="w-10 h-10 rounded-full bg-primary flex items-center justify-center"
          >
            <Unlock className="w-4 h-4 text-primary-foreground" />
          </motion.div>
        ) : (
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="w-10 h-10 rounded-full bg-secondary/20 border border-secondary flex items-center justify-center"
          >
            <ChevronRight className="w-4 h-4 text-secondary" />
          </motion.div>
        )}
      </div>

      {/* Icon */}
      <div className="mb-4 mt-4">
        <div className={`
          w-16 h-16 rounded-xl flex items-center justify-center
          ${isLocked ? 'bg-muted' : 'bg-primary/10 border border-primary/30'}
        `}>
          <motion.div
            animate={!isLocked ? { rotate: [0, 360] } : {}}
            transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          >
            {icon}
          </motion.div>
        </div>
      </div>

      {/* Content */}
      <h3 className={`
        font-display text-lg font-bold mb-2
        ${isLocked ? 'text-muted-foreground' : 'text-foreground'}
      `}>
        {title}
      </h3>
      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
        {description}
      </p>

      {/* Action Button */}
      <Button
        variant={isLocked ? 'locked' : isCompleted ? 'outline' : 'cyber'}
        size="sm"
        onClick={onClick}
        disabled={isLocked}
        className="w-full"
      >
        {isLocked ? 'Complete Previous Level' : isCompleted ? 'Play Again' : 'Start Level'}
      </Button>

      {/* Decorative Elements */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
    </motion.div>
  );
};

export default LevelCard;
