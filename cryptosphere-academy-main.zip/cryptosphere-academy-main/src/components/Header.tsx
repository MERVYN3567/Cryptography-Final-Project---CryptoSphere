import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Terminal, Home } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from './ui/button';

const Header: React.FC = () => {
  const location = useLocation();
  const isHome = location.pathname === '/';

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border"
    >
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 group">
          <motion.div
            whileHover={{ rotate: 360 }}
            transition={{ duration: 0.5 }}
            className="w-10 h-10 rounded-lg bg-primary/10 border border-primary flex items-center justify-center"
          >
            <Shield className="w-5 h-5 text-primary" />
          </motion.div>
          <div>
            <h1 className="font-display text-lg font-bold text-foreground group-hover:text-primary transition-colors">
              CryptoSphere
            </h1>
            <p className="text-[10px] text-muted-foreground -mt-1">
              INTERACTIVE
            </p>
          </div>
        </Link>

        {/* Navigation */}
        <nav className="flex items-center gap-4">
          {!isHome && (
            <Link to="/">
              <Button variant="ghost" size="sm">
                <Home className="w-4 h-4" />
                Home
              </Button>
            </Link>
          )}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted/50 border border-border">
            <Terminal className="w-3 h-3 text-primary" />
            <span className="text-xs text-muted-foreground font-mono">
              v1.0.0
            </span>
          </div>
        </nav>
      </div>
    </motion.header>
  );
};

export default Header;
