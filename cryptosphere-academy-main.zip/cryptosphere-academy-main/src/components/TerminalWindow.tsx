import React from 'react';
import { motion } from 'framer-motion';

interface TerminalWindowProps {
  title?: string;
  children: React.ReactNode;
  className?: string;
}

const TerminalWindow: React.FC<TerminalWindowProps> = ({ 
  title = 'terminal', 
  children,
  className = ''
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`terminal-window scanline ${className}`}
    >
      {/* Terminal Header */}
      <div className="terminal-header">
        <div className="flex gap-2">
          <div className="terminal-dot bg-destructive" />
          <div className="terminal-dot bg-yellow-500" />
          <div className="terminal-dot bg-primary" />
        </div>
        <span className="ml-4 text-xs text-muted-foreground font-mono">
          {title}
        </span>
        <div className="flex-1" />
        <span className="text-xs text-primary/50">
          cryptosphere://secure
        </span>
      </div>
      
      {/* Terminal Content */}
      <div className="p-4 bg-background/50">
        {children}
      </div>
    </motion.div>
  );
};

export default TerminalWindow;
